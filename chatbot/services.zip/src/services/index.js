// src/services/index.js
export { apiService } from './api.js';
export { chatbotService } from './chatbot.js';
export { apiService as default } from './api.js';